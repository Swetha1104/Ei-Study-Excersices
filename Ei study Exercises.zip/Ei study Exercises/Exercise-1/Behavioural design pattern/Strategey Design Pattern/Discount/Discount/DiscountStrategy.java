package Discount;
public interface DiscountStrategy {
       double calculate(double price);
    
}


